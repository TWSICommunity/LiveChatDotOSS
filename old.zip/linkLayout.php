<?php
echo '<a href="index.html">Home</a> >> <a href="enter.html">Enter Livechat</a> >> <a href="faq.html"> >> <a href="rules.html">Read the rules</a>';
?>
