<?php
echo "<center><p><h1>Welcome to Livechat.oss - An open source php script.</h1></center><b>A new user?</b><br>Not to worry, you can register an account. <a href='register.html'>Register link</a> will send you to a registration form page.<br><br><b>Already a registered user?</b><br>If you have already registered an account then click on this <a href='login.html'>Login link</a> to login to your account by using the login form page.</p>";
?>
