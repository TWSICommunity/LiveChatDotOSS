<?php

echo "<form action='form.php' method='POST'>
 Username:<br><input type='text' name='username' placeholder='Username ID' /><br>
 Password:<br><input type='password' name='password-current' placeholder='Password' /><br>
 <input type='submit' name='login' />
</form>";

?>