var httpRequest = new XMLHttpRequest();
var dataRequest = new FormData();
var mainLinksrc = ""; //*Required* Put a slash at the end of your mainLinksrc.

initcolumn='';
initcolumn=setInterval(loadContent, 1000);

function init() {
  console.log("Loading link pages.");
  httpRequest.open("GET", mainLinksrc+"linkLayout.php", true);
  httpRequest.onload = function() {
    document.getElementById("Links").innerHTML = this.responseText;
  }
  httpRequest.send();
}

function loadContent(page = "loginContent.php") {
 console.log("Loading content page.");
 httpRequest.open("GET", mainLinksrc+page, true);
 httpRequest.onload = function() {
  document.getElementById("bodypage").innerHTML = this.responseText;
 }
 httpRequest.send();
 clearInterval(initcolumn);
}
